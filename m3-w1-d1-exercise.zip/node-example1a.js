// node-example1a.js
var myLogModule = require('./node-example1.js');

myLogModule.info('Node.js started');
myLogModule.warning('Node.js has a warning');
myLogModule.error('Node.js has an error');
