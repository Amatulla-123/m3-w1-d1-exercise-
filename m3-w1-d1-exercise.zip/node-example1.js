// node-example1.js
exports.info = function (msg) {
  console.log("Info: " + msg);
};

exports.warning = function (msg) {
  console.log("Warning: " + msg);
};

exports.error = function (msg) {
  console.log("Error: " + msg);
};
