// node-example3a.js
exports.perimeter = (x, y) => 2 * (x + y);
exports.area = (x, y) => x * y;
